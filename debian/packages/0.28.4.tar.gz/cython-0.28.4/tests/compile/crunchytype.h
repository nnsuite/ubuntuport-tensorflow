
struct CrunchyType {
  int number;
  PyObject* string;
};
