#if defined _MSC_VER && defined __cplusplus
#define CYTHON_CCOMPLEX 0
#endif
