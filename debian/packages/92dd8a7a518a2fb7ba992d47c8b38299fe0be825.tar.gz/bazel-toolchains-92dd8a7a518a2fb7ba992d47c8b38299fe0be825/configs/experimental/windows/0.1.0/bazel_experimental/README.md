This directory contains the toolchain config that works with 
Bazel committed at a320e4460f35767da7fc8eb824ce1f4b304b5e0f.
(Approximately dated Jun 13, 2018).
