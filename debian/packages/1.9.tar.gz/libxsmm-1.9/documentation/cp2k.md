# CP2K Open Source Molecular Dynamics

The [document](https://xconfigure.readthedocs.io/cp2k/README/) ([PDF](https://github.com/hfp/xconfigure/raw/master/xconfigure.pdf)) has been incorporated into the XCONFIGURE project (see [https://github.com/hfp/xconfigure](https://xconfigure.readthedocs.io/)).

