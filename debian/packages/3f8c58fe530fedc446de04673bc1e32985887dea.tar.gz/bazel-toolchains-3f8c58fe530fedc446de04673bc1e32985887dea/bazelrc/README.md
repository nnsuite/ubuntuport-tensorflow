This directory contains sample bazelrc files for various versions of bazel.
These files may be copied or imported to your own bazelrc file to enable remote
execution. For more information on using bazelrc files, see
https://docs.bazel.build/versions/master/user-manual.html#bazelrc
