This folder contains a sample Dockerfile that uses as base
gcr.io/cloud-marketplace/google/clang-debian8:latest and installs all the
tools necessary to run Bazel.
