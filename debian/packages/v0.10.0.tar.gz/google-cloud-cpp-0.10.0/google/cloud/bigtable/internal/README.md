# Internal Classes and Functions for Cloud Bigtable Client

This directory (`google/cloud/bigtable/internal/`) contains implementation classes
for the Cloud Bigtable Client. They are not intended for general use. They are
subject to change without notice. Do not use any class, function, or type in
this directory directly in your own applications.
