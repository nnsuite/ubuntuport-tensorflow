# Support Files for googleapis.github.io Landing Page

This directory contains hand-crafted HTML and resource files deployed to
the [google-cloud-cpp landing page][docs link]

[docs link]: https://googleapis.github.io/google-cloud-cpp
