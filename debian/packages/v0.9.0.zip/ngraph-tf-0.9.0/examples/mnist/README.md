Command to run the training is as below:
    `python mnist_deep_simplified.py`
Using this command, the training data will be saved in `./mnist_trained/`

Command to run the inference is as below:
    `python mnist_cnn_inference.py --model_dir=/path/to/your/trained/model/dir/`
The default setup will read data from directory `./mnist_trained/`
