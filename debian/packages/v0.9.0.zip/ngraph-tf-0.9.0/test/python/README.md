`flake8 *.py && pytest`

If you're troubleshooting a particularly troublesome unit test you may find `pytest --pdb` to be more convenient.
