<?php

require_once("vendor/autoload.php");

error_reporting(E_ALL);
