# Support Files for GoogleCloudPlatform.github.io Landing Page

This directory contains hand-crafted HTML and resource files deployed to
the [google-cloud-cpp landing page][docs link]

[docs link]: https://GoogleCloudPlatform.github.io/google-cloud-cpp
