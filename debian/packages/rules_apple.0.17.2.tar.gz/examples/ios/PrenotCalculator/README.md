# PrenotCalculator example

The example in this directory shows a more thorough example of Objective C
libraries, binaries, imports, and some other resource types.

Build the top-level application with
`bazel build examples/ios/PrenotCalculator`; when finished it will print the
path to the generated `.ipa`, which you can then install to your test device.
