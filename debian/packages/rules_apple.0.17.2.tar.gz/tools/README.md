# Internal Apple bundling Tools

Everything in this directory and subdirectories are internal implementation
details for the Apple rules. They should not be used directly by anything
else.
