API for managing lightweight user-provided functions executed in response to
events.