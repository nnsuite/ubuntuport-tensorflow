Read more about the Stackdriver Error Reporting API [here](https://cloud.google.com/error-reporting/reference/)
