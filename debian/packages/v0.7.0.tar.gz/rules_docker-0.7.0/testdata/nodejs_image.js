var jsesc = require('jsesc');

console.log(jsesc('Hello World!'));
console.log(process.argv.slice(2))
