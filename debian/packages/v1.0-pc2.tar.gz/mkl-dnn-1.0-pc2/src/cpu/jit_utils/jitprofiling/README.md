This code is from [Intel SEAPI library](https://github.com/intel/IntelSEAPI)
